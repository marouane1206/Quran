"""
"""
from pyquran.tools import quran
from pyquran.tools import arabic
from pyquran.core.pyquran  import *
